<?php

function getPassword(){
    $password = "RogerRoger123";
    return $password;
}
?>