<footer>
    <p><a href="https://roger.costra.ec" target="_blanc">Roger Paredes - 2024</a></p>
</footer>

    <!-- Bootstrap JS and dependencies -->
    <!-- <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script> -->
    <script src="/Fitform/public/js/jquery-3.5.1.slim.min.js"></script>
    <script src="/Fitform/public/js/popper.min.js"></script>
    <script src="/Fitform/public/js/bootstrap.min.js"></script>



</body>
</html>
